package com.example.mypc.mycontactlist;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;


public class ShowMemo extends Activity {
    private Contact currentContact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_memo);
        initMapButton();
        initListButton();
        initSaveButton();
        initSettingsButton();
        initToggleButton();
        initTextChangedEvents();
        Bundle extra = getIntent().getExtras();
        if (extra!=null)
        {
            initMemo(extra.getInt("contactid"));
        }
        else
        {
            currentContact = new Contact();
        }
        setForEditing(false);
    }
    private void initListButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonList);
        list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ShowMemo.this, ContactListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initMapButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonMap);
        list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ShowMemo.this, ContactMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initSettingsButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonSettings);
        list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ShowMemo.this, ContactSettingsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initTextChangedEvents(){
        final EditText memoedit = (EditText) findViewById(R.id.editMemo);
        memoedit.addTextChangedListener(new TextWatcher(){
            public void afterTextChanged(Editable s) {
                currentContact.setMemo(memoedit.getText().toString());
            }
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
                //  Auto-generated method stub

            }
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                //  Auto-generated method stub
            }
        });
    }
    private void initSaveButton() {
        Button saveButton = (Button) findViewById(R.id.buttonSaveMemo);
        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                hideKeyboard();
                ContactDataSource ds = new ContactDataSource(ShowMemo.this);
                ds.open();

                boolean wasSuccessful = false;
                if (currentContact.getContactID()==-1) {
                    wasSuccessful = ds.insertContact(currentContact);
                    int newId = ds.getLastContactId();
                    currentContact.setContactID(newId);
                }
                else {
                    wasSuccessful = ds.updateContact(currentContact);
                }
                ds.close();

                if (wasSuccessful) {
                    ToggleButton editToggle = (ToggleButton) findViewById(R.id.toggleButtonEditMemo);
                    editToggle.toggle();
                    setForEditing(false);
                }
            }
        });
    }
    private void initToggleButton() {
        final ToggleButton editToggle = (ToggleButton) findViewById(R.id.toggleButtonEditMemo);
        editToggle.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                setForEditing(editToggle.isChecked());
            }

        });
    }

    private void setForEditing(boolean enabled) {
        EditText editMemo = (EditText) findViewById(R.id.editMemo);

        editMemo.setEnabled(enabled);

        if (enabled) {
            editMemo.requestFocus();
        }
        else {
            editMemo.setEnabled(enabled);
        }
    }
    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        EditText editMemo = (EditText) findViewById(R.id.editMemo);
        imm.hideSoftInputFromWindow(editMemo.getWindowToken(), 0);
    }


    private void initMemo(int id){
        ContactDataSource ds = new ContactDataSource(ShowMemo.this);

        ds.open();
        currentContact = ds.getSpecificContact(id);
        ds.close();
        TextView txtname = (TextView) findViewById(R.id.textNameMemo);
        txtname.setText(currentContact.getContactName());
        EditText txt = (EditText) findViewById(R.id.editMemo);
        txt.setText(currentContact.getMemo());
    }

//    private void getMemo(int id){
//        ContactDataSource ds = new ContactDataSource(ShowMemo.this);
//
//        ds.open();
//        Contact currentContact = ds.getSpecificContact(id);
//        ds.close();
//        TextView txtName = (TextView) findViewById(R.id.textNameMemo);
//        EditText memo = (EditText) findViewById(R.id.editMemo);
//        txtName.setText(currentContact.getContactName());
//        memo.setText(currentContact.getStreetAddress());
//    }
}
